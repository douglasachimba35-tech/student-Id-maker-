# Student ID Maker — Android Flutter MVP

This version adds:
- Administrator PIN login (first-time PIN: `1234`)
- Institution settings (name, address, website, phone, footer)
- Change administrator PIN
- Local SQLite student database for hundreds/thousands of students
- Automatic unique 9-digit student IDs
- Student photo and school logo
- QR code on cards
- Search and bulk card generation
- PNG sharing/export

## Build
1. Install Flutter 3.x and Android Studio.
2. Run `flutter pub get`.
3. Run `flutter run` on an Android phone/emulator.
4. For an installable APK: `flutter build apk --release`.

## First login
PIN: `1234`

Change it immediately from **Settings → Administrator security**.
