import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:screenshot/screenshot.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await StudentDatabase.instance.database;
  runApp(const StudentIdMakerApp());
}

class Student {
  final int? id;
  final String studentId;
  final String name;
  final String regNo;
  final String className;
  final String validity;
  final String footer;
  final String? photoPath;
  final String? logoPath;
  final bool showQr;
  final DateTime createdAt;

  const Student({
    this.id,
    required this.studentId,
    required this.name,
    required this.regNo,
    required this.className,
    required this.validity,
    required this.footer,
    this.photoPath,
    this.logoPath,
    required this.showQr,
    required this.createdAt,
  });

  Map<String, Object?> toMap() => {
        'id': id,
        'student_id': studentId,
        'name': name,
        'reg_no': regNo,
        'class_name': className,
        'validity': validity,
        'footer': footer,
        'photo_path': photoPath,
        'logo_path': logoPath,
        'show_qr': showQr ? 1 : 0,
        'created_at': createdAt.toIso8601String(),
      };

  factory Student.fromMap(Map<String, Object?> m) => Student(
        id: m['id'] as int?,
        studentId: m['student_id'] as String,
        name: m['name'] as String,
        regNo: m['reg_no'] as String,
        className: m['class_name'] as String,
        validity: m['validity'] as String,
        footer: m['footer'] as String,
        photoPath: m['photo_path'] as String?,
        logoPath: m['logo_path'] as String?,
        showQr: (m['show_qr'] as int) == 1,
        createdAt: DateTime.parse(m['created_at'] as String),
      );
}

class StudentDatabase {
  StudentDatabase._();
  static final instance = StudentDatabase._();
  Database? _db;

  Future<Database> get database async {
    if (_db != null) return _db!;
    final dir = await getApplicationDocumentsDirectory();
    final path = p.join(dir.path, 'student_id_maker.db');
    _db = await openDatabase(path, version: 1, onCreate: (db, version) async {
      await db.execute('''
        CREATE TABLE students (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          student_id TEXT NOT NULL UNIQUE,
          name TEXT NOT NULL,
          reg_no TEXT NOT NULL,
          class_name TEXT NOT NULL,
          validity TEXT NOT NULL,
          footer TEXT NOT NULL,
          photo_path TEXT,
          logo_path TEXT,
          show_qr INTEGER NOT NULL DEFAULT 1,
          created_at TEXT NOT NULL
        )
      ''');
      await db.execute('CREATE INDEX idx_students_name ON students(name)');
      await db.execute('CREATE INDEX idx_students_class ON students(class_name)');
    });
    return _db!;
  }

  Future<int> insert(Student student) async {
    final db = await database;
    return db.insert('students', student.toMap(), conflictAlgorithm: ConflictAlgorithm.abort);
  }

  Future<void> update(Student student) async {
    final db = await database;
    await db.update('students', student.toMap(), where: 'id = ?', whereArgs: [student.id]);
  }

  Future<void> delete(int id) async {
    final db = await database;
    await db.delete('students', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<Student>> all({String query = ''}) async {
    final db = await database;
    final q = query.trim();
    final rows = await db.query(
      'students',
      where: q.isEmpty ? null : 'name LIKE ? OR student_id LIKE ? OR reg_no LIKE ? OR class_name LIKE ?',
      whereArgs: q.isEmpty ? null : ['%$q%', '%$q%', '%$q%', '%$q%'],
      orderBy: 'created_at DESC',
    );
    return rows.map(Student.fromMap).toList();
  }

  Future<int> count() async {
    final db = await database;
    final result = await db.rawQuery('SELECT COUNT(*) AS count FROM students');
    return Sqflite.firstIntValue(result) ?? 0;
  }
}

class IdNumberGenerator {
  static const key = 'next_student_id';
  static const first = 100000001;

  static Future<String> next() async {
    final prefs = await SharedPreferences.getInstance();
    final value = prefs.getInt(key) ?? first;
    await prefs.setInt(key, value + 1);
    return value.toString().padLeft(9, '0');
  }
}


class InstitutionSettings {
  static const _name = 'institution_name';
  static const _address = 'institution_address';
  static const _website = 'institution_website';
  static const _phone = 'institution_phone';
  static const _footer = 'institution_footer';
  static const _pin = 'admin_pin';

  String name;
  String address;
  String website;
  String phone;
  String footer;

  InstitutionSettings({this.name = 'YOUR INSTITUTION NAME', this.address = 'P.O. BOX 000-00000, KENYA', this.website = 'www.yourinstitution.ac.ke', this.phone = '0700000000 / 0750000000', this.footer = 'If lost contact the institution'});

  static Future<InstitutionSettings> load() async {
    final p = await SharedPreferences.getInstance();
    return InstitutionSettings(
      name: p.getString(_name) ?? 'YOUR INSTITUTION NAME',
      address: p.getString(_address) ?? 'P.O. BOX 000-00000, KENYA',
      website: p.getString(_website) ?? 'www.yourinstitution.ac.ke',
      phone: p.getString(_phone) ?? '0700000000 / 0750000000',
      footer: p.getString(_footer) ?? 'If lost contact the institution',
    );
  }

  Future<void> save() async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_name, name);
    await p.setString(_address, address);
    await p.setString(_website, website);
    await p.setString(_phone, phone);
    await p.setString(_footer, footer);
  }

  static Future<String> pin() async => (await SharedPreferences.getInstance()).getString(_pin) ?? '1234';
  static Future<void> setPin(String pin) async => (await SharedPreferences.getInstance()).setString(_pin, pin);
}

class AdminGate extends StatefulWidget {
  const AdminGate({super.key});
  @override State<AdminGate> createState() => _AdminGateState();
}

class _AdminGateState extends State<AdminGate> {
  final pin = TextEditingController();
  bool busy = false;
  String? error;

  Future<void> login() async {
    if (pin.text.length < 4) { setState(() => error = 'Enter your administrator PIN.'); return; }
    setState(() { busy = true; error = null; });
    final correct = await InstitutionSettings.pin();
    if (!mounted) return;
    if (pin.text == correct) {
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const HomeScreen()));
    } else {
      setState(() { busy = false; error = 'Incorrect PIN.'; });
    }
  }

  @override Widget build(BuildContext context) => Scaffold(
    body: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(28), child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 430), child: Column(children: [
      Container(width: 82, height: 82, decoration: const BoxDecoration(color: Color(0xFF49B51E), shape: BoxShape.circle), child: const Icon(Icons.admin_panel_settings, color: Colors.white, size: 46)),
      const SizedBox(height: 20), const Text('Administrator Login', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
      const SizedBox(height: 8), const Text('Manage students and generate official ID cards.', textAlign: TextAlign.center),
      const SizedBox(height: 28), TextField(controller: pin, obscureText: true, keyboardType: TextInputType.number, maxLength: 8, decoration: InputDecoration(labelText: 'Administrator PIN', prefixIcon: const Icon(Icons.lock_outline), errorText: error)),
      const SizedBox(height: 14), SizedBox(width: double.infinity, height: 54, child: FilledButton(onPressed: busy ? null : login, child: busy ? const CircularProgressIndicator() : const Text('Sign in'))),
      const SizedBox(height: 14), const Text('First-time PIN: 1234', style: TextStyle(color: Colors.black54)),
    ]))),
  );
}

class StudentIdMakerApp extends StatelessWidget {
  const StudentIdMakerApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Student ID Maker',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF49B51E)),
          scaffoldBackgroundColor: const Color(0xFFF4F7F2),
          inputDecorationTheme: InputDecorationTheme(
            filled: true,
            fillColor: Colors.white,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: Color(0xFFE2E7E0))),
            focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: Color(0xFF49B51E), width: 1.5)),
          ),
        ),
        home: const AdminGate(),
      );
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _tab = 0;
  int _refresh = 0;
  InstitutionSettings? settings;

  void refresh() => setState(() => _refresh++);

  @override void initState() { super.initState(); InstitutionSettings.load().then((v) { if (mounted) setState(() => settings = v); }); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _tab,
        children: [
          EditorScreen(onSaved: refresh, settings: settings ?? InstitutionSettings()),
          StudentsScreen(key: ValueKey(_refresh), onChanged: refresh, settings: settings ?? InstitutionSettings()),
          SettingsScreen(onSaved: () async { final v = await InstitutionSettings.load(); if (mounted) setState(() => settings = v); }),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (v) => setState(() => _tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.add_card_outlined), selectedIcon: Icon(Icons.add_card), label: 'Create'),
          NavigationDestination(icon: Icon(Icons.people_outline), selectedIcon: Icon(Icons.people), label: 'Students'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'Settings'),
        ],
      ),
    );
  }
}

class EditorScreen extends StatefulWidget {
  final VoidCallback onSaved;
  final Student? existing;
  final InstitutionSettings settings;
  const EditorScreen({super.key, required this.onSaved, this.existing, required this.settings});

  @override
  State<EditorScreen> createState() => _EditorScreenState();
}

class _EditorScreenState extends State<EditorScreen> {
  final formKey = GlobalKey<FormState>();
  final screenshotController = ScreenshotController();
  final picker = ImagePicker();
  final name = TextEditingController();
  final studentId = TextEditingController();
  final regNo = TextEditingController();
  final className = TextEditingController();
  final validity = TextEditingController();
  final footer = TextEditingController();
  File? photo;
  File? logo;
  bool showQr = true;
  bool autoId = true;
  bool busy = false;
  bool generatingId = false;

  @override
  void initState() {
    super.initState();
    final s = widget.existing;
    if (s == null) { InstitutionSettings.load().then((v) { if (mounted && footer.text.isEmpty) setState(() => footer.text = v.footer); }); }
    if (s != null) {
      name.text = s.name;
      studentId.text = s.studentId;
      regNo.text = s.regNo;
      className.text = s.className;
      validity.text = s.validity;
      footer.text = s.footer;
      showQr = s.showQr;
      if (s.photoPath != null) photo = File(s.photoPath!);
      if (s.logoPath != null) logo = File(s.logoPath!);
    }
  }

  @override
  void dispose() {
    for (final c in [name, studentId, regNo, className, validity, footer]) c.dispose();
    super.dispose();
  }

  Future<void> generateId() async {
    if (generatingId) return;
    setState(() => generatingId = true);
    try {
      final id = await IdNumberGenerator.next();
      if (mounted) setState(() => studentId.text = id);
    } finally {
      if (mounted) setState(() => generatingId = false);
    }
  }

  Future<void> pickImage({required bool isLogo}) async {
    final file = await picker.pickImage(source: ImageSource.gallery, imageQuality: 90, maxWidth: 1600);
    if (file == null) return;
    setState(() {
      if (isLogo) logo = File(file.path); else photo = File(file.path);
    });
  }

  Future<String?> copyToApp(File? file, String prefix) async {
    if (file == null) return null;
    final dir = await getApplicationDocumentsDirectory();
    final folder = Directory(p.join(dir.path, 'student_assets'));
    if (!await folder.exists()) await folder.create(recursive: true);
    final ext = p.extension(file.path).isEmpty ? '.jpg' : p.extension(file.path);
    final target = File(p.join(folder.path, '${prefix}_${DateTime.now().microsecondsSinceEpoch}$ext'));
    await file.copy(target.path);
    return target.path;
  }

  Future<void> saveStudent({bool shareAfter = false}) async {
    if (!(formKey.currentState?.validate() ?? false)) return;
    if (studentId.text.trim().isEmpty) await generateId();
    setState(() => busy = true);
    try {
      final photoPath = await copyToApp(photo, 'photo');
      final logoPath = await copyToApp(logo, 'logo');
      final s = Student(
        id: widget.existing?.id,
        studentId: studentId.text.trim(),
        name: name.text.trim(),
        regNo: regNo.text.trim(),
        className: className.text.trim(),
        validity: validity.text.trim(),
        footer: footer.text.trim(),
        photoPath: photoPath ?? widget.existing?.photoPath,
        logoPath: logoPath ?? widget.existing?.logoPath,
        showQr: showQr,
        createdAt: widget.existing?.createdAt ?? DateTime.now(),
      );
      if (widget.existing == null) {
        await StudentDatabase.instance.insert(s);
      } else {
        await StudentDatabase.instance.update(s);
      }
      widget.onSaved();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(widget.existing == null ? 'Student saved.' : 'Student updated.')));
      if (shareAfter) await exportStudent(s);
    } on DatabaseException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString().contains('UNIQUE') ? 'That student ID already exists.' : 'Database error: $e')));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> exportStudent(Student s) async {
    final controller = ScreenshotController();
    final card = Screenshot(
      controller: controller,
      child: SizedBox(width: 856, height: 540, child: StudentCard(student: s, settings: settings)),
    );
    // Give Flutter one frame to layout the offscreen widget by placing it in a route.
    final bytes = await showDialog<Uint8List>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => _HiddenCardCapture(controller: controller, card: card),
    );
    if (bytes == null) return;
    final dir = await getTemporaryDirectory();
    final file = File(p.join(dir.path, 'student_id_${s.studentId}.png'));
    await file.writeAsBytes(bytes, flush: true);
    await Share.shareXFiles([XFile(file.path)], text: 'Student ID card - ${s.name}');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.existing == null ? 'Create Student ID' : 'Edit Student'), backgroundColor: Colors.transparent),
      body: SafeArea(
        child: Form(
          key: formKey,
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 30),
            children: [
              const Text('Student details', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
              const SizedBox(height: 12),
              TextFormField(controller: name, textCapitalization: TextCapitalization.words, decoration: _dec('Full name', Icons.person_outline), validator: (v) => v == null || v.trim().isEmpty ? 'Enter the student name' : null, onChanged: (_) async { setState(() {}); if (autoId && studentId.text.isEmpty && name.text.trim().isNotEmpty) await generateId(); }),
              const SizedBox(height: 10),
              Row(children: [
                Expanded(child: TextFormField(controller: studentId, keyboardType: TextInputType.number, decoration: _dec('Student ID', Icons.badge_outlined), validator: (v) => v == null || v.trim().isEmpty ? 'Generate or enter the student ID' : null, onChanged: (_) => setState(() {}))),
                const SizedBox(width: 8),
                SizedBox(height: 56, child: OutlinedButton(onPressed: generatingId ? null : generateId, child: generatingId ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.autorenew))),
              ]),
              SwitchListTile.adaptive(contentPadding: const EdgeInsets.symmetric(horizontal: 4), title: const Text('Automatic ID generation', style: TextStyle(fontWeight: FontWeight.w700)), subtitle: const Text('Assign a unique 9-digit ID to new students.'), value: autoId, onChanged: (v) => setState(() => autoId = v)),
              const SizedBox(height: 4),
              TextFormField(controller: regNo, decoration: _dec('Registration number', Icons.assignment_ind_outlined), validator: (v) => v == null || v.trim().isEmpty ? 'Enter registration number' : null, onChanged: (_) => setState(() {})),
              const SizedBox(height: 10),
              TextFormField(controller: className, decoration: _dec('Class / Course', Icons.school_outlined), validator: (v) => v == null || v.trim().isEmpty ? 'Enter class/course' : null, onChanged: (_) => setState(() {})),
              const SizedBox(height: 10),
              TextFormField(controller: validity, decoration: _dec('Validity', Icons.date_range_outlined), validator: (v) => v == null || v.trim().isEmpty ? 'Enter validity dates' : null, onChanged: (_) => setState(() {})),
              const SizedBox(height: 10),
              TextFormField(controller: footer, decoration: _dec('Footer / lost-card message', Icons.info_outline), maxLines: 2, onChanged: (_) => setState(() {})),
              const SizedBox(height: 16),
              const Text('Images', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
              const SizedBox(height: 12),
              Row(children: [Expanded(child: _upload('Student photo', Icons.photo_camera_outlined, false)), const SizedBox(width: 10), Expanded(child: _upload('School logo', Icons.account_balance_outlined, true))]),
              SwitchListTile.adaptive(contentPadding: const EdgeInsets.symmetric(horizontal: 4), title: const Text('Show QR verification code', style: TextStyle(fontWeight: FontWeight.w700)), value: showQr, onChanged: (v) => setState(() => showQr = v)),
              const SizedBox(height: 8),
              const Text('Live preview', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
              const SizedBox(height: 10),
              Center(child: Screenshot(controller: screenshotController, child: SizedBox(width: 856, height: 540, child: StudentCard(student: Student(studentId: studentId.text.isEmpty ? '000000000' : studentId.text, name: name.text.isEmpty ? 'STUDENT NAME' : name.text.toUpperCase(), regNo: regNo.text.isEmpty ? 'REG/0000' : regNo.text.toUpperCase(), className: className.text.isEmpty ? 'COURSE / CLASS' : className.text.toUpperCase(), validity: validity.text.isEmpty ? 'DD/MM/YYYY - DD/MM/YYYY' : validity.text, footer: footer.text.isEmpty ? settings.footer : footer.text, photoPath: photo?.path, logoPath: logo?.path, showQr: showQr, createdAt: DateTime.now()), settings: settings)))),
              const SizedBox(height: 16),
              FilledButton.icon(onPressed: busy ? null : () => saveStudent(), icon: busy ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.save_outlined), label: Text(busy ? 'Saving…' : widget.existing == null ? 'Save Student' : 'Save Changes'), style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(54))),
              const SizedBox(height: 8),
              OutlinedButton.icon(onPressed: busy ? null : () async { await saveStudent(shareAfter: true); }, icon: const Icon(Icons.ios_share_outlined), label: const Text('Save & Generate Card'), style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(52))),
            ],
          ),
        ),
      ),
    );
  }

  InputDecoration _dec(String label, IconData icon) => InputDecoration(labelText: label, prefixIcon: Icon(icon));

  Widget _upload(String label, IconData icon, bool isLogo) {
    final exists = isLogo ? logo != null : photo != null;
    return OutlinedButton.icon(onPressed: () => pickImage(isLogo: isLogo), icon: Icon(exists ? Icons.check_circle_outline : icon), label: Text(exists ? '$label added' : 'Add $label'), style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(52)));
  }
}

class _HiddenCardCapture extends StatefulWidget {
  final ScreenshotController controller;
  final Widget card;
  const _HiddenCardCapture({required this.controller, required this.card});
  @override State<_HiddenCardCapture> createState() => _HiddenCardCaptureState();
}
class _HiddenCardCaptureState extends State<_HiddenCardCapture> {
  @override
  void initState() { super.initState(); WidgetsBinding.instance.addPostFrameCallback((_) async { final bytes = await widget.controller.capture(pixelRatio: 2.5); if (mounted) Navigator.of(context).pop(bytes); }); }
  @override Widget build(BuildContext context) => Dialog(child: SizedBox(width: 856, height: 540, child: widget.card));
}

class StudentsScreen extends StatefulWidget {
  final VoidCallback onChanged;
  final InstitutionSettings settings;
  const StudentsScreen({super.key, required this.onChanged, required this.settings});
  @override State<StudentsScreen> createState() => _StudentsScreenState();
}

class _StudentsScreenState extends State<StudentsScreen> {
  final search = TextEditingController();
  List<Student> students = [];
  bool loading = true;
  bool selectedMode = false;
  final selected = <int>{};

  @override
  void initState() { super.initState(); load(); search.addListener(load); }
  @override
  void dispose() { search.removeListener(load); search.dispose(); super.dispose(); }

  Future<void> load() async {
    final rows = await StudentDatabase.instance.all(query: search.text);
    if (mounted) setState(() { students = rows; loading = false; });
  }

  Future<void> deleteStudent(Student s) async {
    final yes = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(title: const Text('Delete student?'), content: Text('Delete ${s.name} (${s.studentId}) from the database?'), actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Delete'))]));
    if (yes != true || s.id == null) return;
    await StudentDatabase.instance.delete(s.id!);
    selected.remove(s.id);
    await load();
    widget.onChanged();
  }

  Future<void> bulkGenerate() async {
    final targets = selectedMode ? students.where((s) => selected.contains(s.id)).toList() : students;
    if (targets.isEmpty) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('No students selected.'))); return; }
    setState(() => loading = true);
    try {
      final dir = await getTemporaryDirectory();
      final files = <XFile>[];
      for (final s in targets) {
        final controller = ScreenshotController();
        final bytes = await showDialog<Uint8List>(context: context, barrierDismissible: false, builder: (ctx) => _HiddenCardCapture(controller: controller, card: SizedBox(width: 856, height: 540, child: StudentCard(student: s, settings: settings))));
        if (bytes == null) continue;
        final file = File(p.join(dir.path, 'student_id_${s.studentId}.png'));
        await file.writeAsBytes(bytes, flush: true);
        files.add(XFile(file.path));
      }
      if (files.isNotEmpty) await Share.shareXFiles(files, text: 'Student ID cards (${files.length})');
    } finally { if (mounted) setState(() => loading = false); }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Students'), backgroundColor: Colors.transparent, actions: [IconButton(onPressed: load, icon: const Icon(Icons.refresh))]),
      floatingActionButton: selectedMode && selected.isNotEmpty ? FloatingActionButton.extended(onPressed: loading ? null : bulkGenerate, icon: const Icon(Icons.auto_awesome), label: Text('Generate ${selected.length}')) : null,
      body: Column(children: [
        Padding(padding: const EdgeInsets.fromLTRB(16, 4, 16, 8), child: SearchBar(controller: search, hintText: 'Search name, ID, registration or class', leading: const Icon(Icons.search), trailing: [if (search.text.isNotEmpty) IconButton(onPressed: () => search.clear(), icon: const Icon(Icons.clear))])),
        Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: Row(children: [Expanded(child: Text('${students.length} student${students.length == 1 ? '' : 's'} saved', style: const TextStyle(fontWeight: FontWeight.w700))), TextButton.icon(onPressed: () => setState(() { selectedMode = !selectedMode; if (!selectedMode) selected.clear(); }), icon: Icon(selectedMode ? Icons.close : Icons.checklist), label: Text(selectedMode ? 'Cancel' : 'Select'))])),
        Expanded(child: loading ? const Center(child: CircularProgressIndicator()) : students.isEmpty ? const Center(child: Text('No students saved yet.')) : ListView.separated(padding: const EdgeInsets.fromLTRB(12, 4, 12, 90), itemCount: students.length, separatorBuilder: (_, __) => const SizedBox(height: 6), itemBuilder: (context, i) {
          final s = students[i];
          return Card(child: ListTile(leading: selectedMode ? Checkbox(value: selected.contains(s.id), onChanged: (v) => setState(() { if (v == true) selected.add(s.id!); else selected.remove(s.id); })) : CircleAvatar(child: Text(s.name.isEmpty ? '?' : s.name[0].toUpperCase())), title: Text(s.name, style: const TextStyle(fontWeight: FontWeight.w800)), subtitle: Text('${s.studentId} • ${s.className}\n${s.regNo}'), isThreeLine: true, trailing: PopupMenuButton<String>(onSelected: (v) async { if (v == 'generate') { final controller = ScreenshotController(); final bytes = await showDialog<Uint8List>(context: context, barrierDismissible: false, builder: (ctx) => _HiddenCardCapture(controller: controller, card: SizedBox(width: 856, height: 540, child: StudentCard(student: s, settings: settings)))); if (bytes != null) { final dir = await getTemporaryDirectory(); final file = File(p.join(dir.path, 'student_id_${s.studentId}.png')); await file.writeAsBytes(bytes, flush: true); await Share.shareXFiles([XFile(file.path)], text: 'Student ID card - ${s.name}'); } } else if (v == 'delete') await deleteStudent(s); }, itemBuilder: (_) => const [PopupMenuItem(value: 'generate', child: Text('Generate card')), PopupMenuItem(value: 'delete', child: Text('Delete'))])));
        }))
      ]),
    );
  }
}


class SettingsScreen extends StatefulWidget {
  final VoidCallback onSaved;
  const SettingsScreen({super.key, required this.onSaved});
  @override State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final name = TextEditingController(), address = TextEditingController(), website = TextEditingController(), phone = TextEditingController(), footer = TextEditingController();
  final currentPin = TextEditingController(), newPin = TextEditingController();
  bool loading = true, saving = false;
  @override void initState() { super.initState(); load(); }
  Future<void> load() async { final s = await InstitutionSettings.load(); if (!mounted) return; name.text=s.name; address.text=s.address; website.text=s.website; phone.text=s.phone; footer.text=s.footer; setState(()=>loading=false); }
  Future<void> save() async { setState(()=>saving=true); final s=InstitutionSettings(name:name.text.trim(), address:address.text.trim(), website:website.text.trim(), phone:phone.text.trim(), footer:footer.text.trim()); await s.save(); if (newPin.text.isNotEmpty) { final old=await InstitutionSettings.pin(); if (currentPin.text != old) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Current PIN is incorrect.'))); setState(()=>saving=false); return; } if (newPin.text.length < 4) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('New PIN must have at least 4 digits.'))); setState(()=>saving=false); return; } await InstitutionSettings.setPin(newPin.text); } widget.onSaved(); if (mounted) { setState(()=>saving=false); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Settings saved.'))); } }
  @override void dispose(){ for(final c in [name,address,website,phone,footer,currentPin,newPin]) c.dispose(); super.dispose(); }
  @override Widget build(BuildContext context){ if(loading) return const Center(child:CircularProgressIndicator()); return Scaffold(appBar:AppBar(title:const Text('Institution Settings'),backgroundColor:Colors.transparent), body:ListView(padding:const EdgeInsets.fromLTRB(16,4,16,30), children:[
    const Text('Card information',style:TextStyle(fontSize:20,fontWeight:FontWeight.w900)), const SizedBox(height:12),
    TextField(controller:name,decoration:_d('Institution name',Icons.school_outlined)), const SizedBox(height:10), TextField(controller:address,decoration:_d('Address',Icons.location_on_outlined)), const SizedBox(height:10), TextField(controller:website,decoration:_d('Website',Icons.language_outlined)), const SizedBox(height:10), TextField(controller:phone,decoration:_d('Phone',Icons.phone_outlined)), const SizedBox(height:10), TextField(controller:footer,decoration:_d('Default lost-card message',Icons.info_outline),maxLines:2),
    const SizedBox(height:26), const Text('Administrator security',style:TextStyle(fontSize:20,fontWeight:FontWeight.w900)), const SizedBox(height:8), const Text('Leave the PIN fields empty if you do not want to change the administrator PIN.'), const SizedBox(height:12), TextField(controller:currentPin,obscureText:true,keyboardType:TextInputType.number,decoration:_d('Current PIN',Icons.lock_outline)), const SizedBox(height:10), TextField(controller:newPin,obscureText:true,keyboardType:TextInputType.number,decoration:_d('New PIN',Icons.lock_reset_outlined)), const SizedBox(height:24), SizedBox(height:54,child:FilledButton.icon(onPressed:saving?null:save,icon:saving?const SizedBox(width:20,height:20,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.save),label:Text(saving?'Saving…':'Save Settings')))
  ])); }
  InputDecoration _d(String l,IconData i)=>InputDecoration(labelText:l,prefixIcon:Icon(i));
}

class StudentCard extends StatelessWidget {
  final Student student;
  final InstitutionSettings settings;
  const StudentCard({super.key, required this.student, required this.settings});
  static const green = Color(0xFF49B51E);

  @override
  Widget build(BuildContext context) {
    final photo = student.photoPath != null ? File(student.photoPath!) : null;
    final logo = student.logoPath != null ? File(student.logoPath!) : null;
    return ClipRRect(borderRadius: BorderRadius.circular(18), child: Material(color: Colors.white, child: Stack(children: [
      Positioned.fill(child: Container(color: Colors.white)),
      Positioned(left: 0, right: 0, bottom: 0, height: 140, child: Container(color: green)),
      Positioned(left: 0, right: 0, bottom: 137, height: 3, child: Container(color: const Color(0xFFD7D9DC))),
      Positioned(left: 34, top: 54, width: 135, height: 108, child: logo == null ? const Icon(Icons.account_balance, color: green, size: 70) : Image.file(logo, fit: BoxFit.contain)),
      Positioned(right: 34, top: 48, width: 145, height: 120, child: Container(decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: green, width: 5)), child: const Icon(Icons.settings, color: green, size: 62))),
      Positioned(left: 188, right: 180, top: 38, child: Column(children: [FittedBox(child: Text(settings.name.toUpperCase(), style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w900, color: green))), FittedBox(child: Text(settings.address.toUpperCase(), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700))), FittedBox(child: Text('Website: ${settings.website}', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600))), FittedBox(child: Text('Phone: ${settings.phone}', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)))])),
      Positioned(left: 310, right: 310, top: 151, height: 22, child: Container(color: Colors.black)),
      Positioned(left: 51, top: 232, width: 180, height: 195, child: ClipRRect(borderRadius: BorderRadius.circular(3), child: photo == null ? Container(color: const Color(0xFFE9E9E9), child: const Icon(Icons.person, size: 82, color: Colors.black38)) : Image.file(photo, fit: BoxFit.cover))),
      Positioned(left: 265, right: 35, top: 225, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [_row('NAME:', student.name, 20), _row('ID:', student.studentId, 20), _row('REG NO:', student.regNo, 19), _row('Class:', student.className, 19), _row('Validity:', student.validity, 18)])),
      if (student.showQr) Positioned(right: 34, bottom: 18, child: Container(padding: const EdgeInsets.all(4), color: Colors.white, child: QrImageView(data: 'student-id:${student.studentId}', size: 70, backgroundColor: Colors.white))),
      Positioned(left: 42, right: student.showQr ? 260 : 42, bottom: 18, child: Text(student.footer, maxLines: 2, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: const TextStyle(color: Colors.red, fontWeight: FontWeight.w900, fontSize: 16))),
    ])));
  }

  Widget _row(String label, String value, double size) => Padding(padding: const EdgeInsets.only(bottom: 7), child: Row(crossAxisAlignment: CrossAxisAlignment.baseline, textBaseline: TextBaseline.alphabetic, children: [SizedBox(width: 115, child: Text(label, style: TextStyle(color: green, fontSize: size, fontWeight: FontWeight.w900))), Expanded(child: Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: size, fontWeight: FontWeight.w900)))]));
}
